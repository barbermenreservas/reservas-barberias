# 📌 Reservas Barbería

Este proyecto contiene dos páginas web simples para gestionar reservas en una barbería:

- **`reservas.html`** → Formulario para que los clientes puedan hacer su reserva.  
- **`agenda.html`** → Agenda donde la barbería puede ver todas las reservas guardadas.  

Las reservas se almacenan en el navegador usando **localStorage**, por lo que no se borran al cerrar la página.

---

## 🚀 Cómo publicar en GitHub Pages

### 1. Subir archivos
1. Entra a tu repositorio en GitHub:  
   👉 [barbermenreservas/reservas-barberias](https://github.com/barbermenreservas/reservas-barberias)  
2. Haz clic en **Add file → Upload files**  
3. Arrastra los archivos:  
   - `reservas.html`  
   - `agenda.html`  
   - `README.md`  
4. Haz clic en **Commit changes** (botón verde).

---

### 2. Activar GitHub Pages
1. Ve a la pestaña **Settings** de tu repositorio.  
2. En el menú lateral izquierdo baja hasta **Pages**.  
3. En la sección **Build and deployment**:  
   - En **Branch**, selecciona:  
     - Rama: `main`  
     - Carpeta: `/ (root)`  
   - Haz clic en **Save**.  

---

### 3. Obtener la URL
Después de unos minutos, GitHub mostrará un mensaje como este:

```
Your site is published at:
https://barbermenreservas.github.io/reservas-barberias/
```

---

## 📌 Enlaces de uso

Cuando tu web esté publicada, podrás acceder a:

- **Formulario de reservas (clientes):**  
  👉 [https://barbermenreservas.github.io/reservas-barberias/reservas.html](https://barbermenreservas.github.io/reservas-barberias/reservas.html)

- **Agenda de reservas (barbería):**  
  👉 [https://barbermenreservas.github.io/reservas-barberias/agenda.html](https://barbermenreservas.github.io/reservas-barberias/agenda.html)

---

## ✅ Notas
- Todo funciona en el navegador, **sin servidor**.  
- Los datos se guardan en `localStorage` y no se pierden al recargar la página.  
- Puedes eliminar reservas directamente desde la agenda.  
