# Reservas Barbería 💈

Este proyecto contiene un sistema básico de reservas para una barbería:

- **reservas.html** → Formulario para que los clientes agenden sus citas.  
- **agenda.html** → Agenda para que los barberos vean y gestionen las reservas.

## 🌐 Uso en GitHub Pages
Una vez desplegado en GitHub Pages, accede con estos enlaces:

- [Reservas (clientes)](./reservas.html)  
- [Agenda (barberos)](./agenda.html)  

---
Desarrollado con ❤️ para Barber Men Reservas.
